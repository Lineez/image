export function initMenu() {
  const menu = document.querySelector('.menu')
  const menuNav = document.querySelector('.menu__nav')
  const menuBurger = document.querySelector('.menu__burger')
	const body = document.body;
  menuBurger.addEventListener('click', () => {
		body.classList.toggle('lock')
    menu.classList.toggle('active')
    menuNav.classList.toggle('active')
    menuBurger.classList.toggle('active')
  })
}